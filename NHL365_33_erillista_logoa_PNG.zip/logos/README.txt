NHL365 - logot poimittu käyttäjän lähettämistä JPG-kuvista. PNG läpinäkyvällä taustalla.
Kuvat ovat JPG-lähteestä tehtyjä rasterileikkauksia, eivät alkuperäisiä SVG-vektoreita.
HUOM: ARI_LEGACY on Arizona Coyotesin vanha logo, EI nykyisen Utah Mammoth -joukkueen logo.
Muutkin logoversiot voivat olla vanhoja. Tarkista ajantasaisuus ja käyttöoikeudet ennen julkista käyttöä.

TOR.png - Toronto Maple Leafs
BOS.png - Boston Bruins
SEA.png - Seattle Kraken
CBJ.png - Columbus Blue Jackets
MTL.png - Montréal Canadiens
LAK.png - Los Angeles Kings
STL.png - St. Louis Blues
CGY.png - Calgary Flames
VGK.png - Vegas Golden Knights
CHI.png - Chicago Blackhawks
NYI.png - New York Islanders
ARI_LEGACY.png - Arizona Coyotes (vanha logo, ei nykyinen Utah Mammoth)
PHI.png - Philadelphia Flyers
WPG.png - Winnipeg Jets
COL.png - Colorado Avalanche
TBL.png - Tampa Bay Lightning
WSH.png - Washington Capitals
CAR.png - Carolina Hurricanes
FLA.png - Florida Panthers
DET.png - Detroit Red Wings
NSH.png - Nashville Predators
DAL.png - Dallas Stars
PIT.png - Pittsburgh Penguins
NYR.png - New York Rangers
VAN.png - Vancouver Canucks
SJS.png - San Jose Sharks
ANA.png - Anaheim Ducks
MIN.png - Minnesota Wild
EDM.png - Edmonton Oilers
OTT.png - Ottawa Senators
NJD.png - New Jersey Devils
BUF.png - Buffalo Sabres
